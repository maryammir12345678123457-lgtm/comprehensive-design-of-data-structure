# Algorithms: Interactive Custom Stack and Hash Table

This file documents the algorithms used by the Java assignment. It is kept separate from the implementation files.

## 1. Array-based stack

The stack stores integers in a fixed-size array `data`. The variable `top` stores the index of the top item; `top = -1` means the stack is empty.

### Initialize

```text
ALGORITHM InitializeStack(capacity)
    IF capacity <= 0
        REPORT invalid capacity
    CREATE array data with capacity elements
    SET top = -1
```

### Push

```text
ALGORITHM Push(value)
    IF top = length(data) - 1
        REPORT stack overflow
    top = top + 1
    data[top] = value
```

### Pop

```text
ALGORITHM Pop()
    IF top = -1
        REPORT stack underflow
    value = data[top]
    top = top - 1
    RETURN value
```

### Peek

```text
ALGORITHM Peek()
    IF top = -1
        REPORT stack is empty
    RETURN data[top]
```

### Stack status and display

```text
ALGORITHM IsEmpty()
    RETURN top = -1

ALGORITHM IsFull()
    RETURN top = length(data) - 1

ALGORITHM Size()
    RETURN top + 1

ALGORITHM DisplayStack()
    IF IsEmpty()
        PRINT "Stack is empty"
    ELSE
        FOR i from 0 through top
            PRINT data[i] in order
        PRINT that data[top] is the top
```

The stack follows **LIFO** order: the last value pushed is the first value popped.

## 2. Custom hash table

The table has a fixed array of buckets. Each bucket is the head of a singly linked list of entries. Linked lists provide **separate chaining** for keys that map to the same bucket. Each entry contains a string key, an integer value, and a link to the next entry.

### Hash function

The implementation uses a custom sum-of-character-codes hash function and does not use Java's `String.hashCode()` or `HashMap`.

```text
ALGORITHM Hash(key)
    IF key is null
        REPORT invalid key
    result = 0
    FOR each character ch in key, from left to right
        result = (result + numeric code of ch) MOD number of buckets
    RETURN result
```

### Put (insert or update)

```text
ALGORITHM Put(key, value)
    index = Hash(key)
    current = buckets[index]

    WHILE current is not null
        IF current.key equals key
            current.value = value
            RETURN                 // updating does not change size
        current = current.next

    added = new Entry(key, value)
    added.next = buckets[index]   // add at head of the chain
    buckets[index] = added
    size = size + 1
```

### Get

```text
ALGORITHM Get(key)
    index = Hash(key)
    current = buckets[index]
    WHILE current is not null
        IF current.key equals key
            RETURN current.value
        current = current.next
    REPORT key not found
```

### Check whether a key exists

```text
ALGORITHM ContainsKey(key)
    index = Hash(key)
    current = buckets[index]
    WHILE current is not null
        IF current.key equals key
            RETURN true
        current = current.next
    RETURN false
```

### Remove

```text
ALGORITHM Remove(key)
    index = Hash(key)
    current = buckets[index]
    previous = null

    WHILE current is not null
        IF current.key equals key
            IF previous is null
                buckets[index] = current.next   // removing first entry
            ELSE
                previous.next = current.next   // removing later entry
            size = size - 1
            RETURN true
        previous = current
        current = current.next

    RETURN false
```

### Display the table

```text
ALGORITHM DisplayTable()
    FOR each bucket index from 0 through number of buckets - 1
        PRINT the index
        IF the bucket is empty
            PRINT "(empty)"
        ELSE
            FOLLOW its linked list and print each key-value pair
    PRINT total number of pairs
```

## 3. Interactive program flow

```text
ALGORITHM Main
    PRINT program heading
    REPEAT until valid positive integer entered
        READ stack capacity
    CREATE stack
    REPEAT until valid positive integer entered
        READ hash-table bucket count
    CREATE hash table

    REPEAT
        PRINT main menu: stack, hash table, or exit
        READ menu choice
        IF choice selects stack
            run StackMenu
        ELSE IF choice selects hash table
            run HashMenu
        ELSE IF choice is exit
            stop loop
        ELSE
            PRINT invalid option
```

`StackMenu` repeats until the user chooses Back. Its options invoke push, pop, peek, display, or stack status. It catches stack-operation errors such as overflow and underflow and reports them without terminating the program.

`HashMenu` repeats until the user chooses Back. Its options invoke put/update, get, contains, remove, display, or table status. Missing keys and invalid keys are reported as appropriate.

Input is read one line at a time using `System.in.read()`. Integer input is parsed; if parsing fails, the program asks again. Positive capacities are validated before the structures are created, and empty text keys are rejected by the interactive input routine.

## 4. Complexity

Let `C` be the array capacity or hash-table bucket count, `n` the number of stored hash-table entries, `L` the length of a key, and `k` the number of entries in the selected bucket.

| Operation | Time | Extra space |
|---|---:|---:|
| Stack push, pop, peek, size, empty/full check | O(1) | O(1) per operation |
| Stack display | O(n) for current stack size | O(1) |
| Stack storage | — | O(C) |
| Hash computation | O(L) | O(1) |
| Hash put/get/contains/remove | O(L + k); expected near O(L) with well-distributed keys, worst O(L + n) | O(1) per operation (excluding a newly inserted entry) |
| Hash-table display | O(C + n) | O(1) |
| Hash-table storage | — | O(C + n) |

The custom additive hash is simple and may distribute some key patterns unevenly. Separate chaining keeps colliding keys accessible, but many collisions increase the time spent traversing a bucket.
