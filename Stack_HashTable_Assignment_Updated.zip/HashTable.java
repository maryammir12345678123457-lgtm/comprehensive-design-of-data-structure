public class HashTable {
    private static class Entry {
        String key;
        int value;
        Entry next;

        Entry(String key, int value) {
            this.key = key;
            this.value = value;
        }
    }

    private final Entry[] buckets;
    private int size;

    public HashTable(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Bucket count must be greater than zero.");
        }
        buckets = new Entry[capacity];
    }

    // Custom hash function; does not use String.hashCode() or HashMap.
    private int hash(String key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        int result = 0;
        for (int i = 0; i < key.length(); i++) {
            result = (result + key.charAt(i)) % buckets.length;
        }
        return result;
    }

    public void put(String key, int value) {
        int index = hash(key);
        Entry current = buckets[index];

        while (current != null) {
            if (current.key.equals(key)) {
                current.value = value;
                return;
            }
            current = current.next;
        }

        Entry added = new Entry(key, value);
        added.next = buckets[index];
        buckets[index] = added;
        size++;
    }

    public int get(String key) {
        int index = hash(key);
        Entry current = buckets[index];
        while (current != null) {
            if (current.key.equals(key)) return current.value;
            current = current.next;
        }
        throw new IllegalArgumentException("Key not found.");
    }

    public boolean containsKey(String key) {
        int index = hash(key);
        Entry current = buckets[index];
        while (current != null) {
            if (current.key.equals(key)) return true;
            current = current.next;
        }
        return false;
    }

    public boolean remove(String key) {
        int index = hash(key);
        Entry current = buckets[index];
        Entry previous = null;

        while (current != null) {
            if (current.key.equals(key)) {
                if (previous == null) buckets[index] = current.next;
                else previous.next = current.next;
                size--;
                return true;
            }
            previous = current;
            current = current.next;
        }
        return false;
    }

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }

    public void display() {
        System.out.println("Hash table buckets:");
        for (int i = 0; i < buckets.length; i++) {
            System.out.print(i + ": ");
            Entry current = buckets[i];
            if (current == null) {
                System.out.println("(empty)");
            } else {
                while (current != null) {
                    System.out.print("[" + current.key + " = " + current.value + "]");
                    if (current.next != null) System.out.print(" -> ");
                    current = current.next;
                }
                System.out.println();
            }
        }
        System.out.println("Total pairs: " + size);
    }
}
