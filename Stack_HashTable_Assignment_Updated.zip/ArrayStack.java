public class ArrayStack {
    private final int[] data;
    private int top;

    public ArrayStack(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be greater than zero.");
        }
        data = new int[capacity];
        top = -1;
    }

    public void push(int value) {
        if (top == data.length - 1) {
            throw new IllegalStateException("Stack is full.");
        }
        top++;
        data[top] = value;
    }

    public int pop() {
        if (top == -1) {
            throw new IllegalStateException("Stack is empty.");
        }
        int value = data[top];
        top--;
        return value;
    }

    public int peek() {
        if (top == -1) {
            throw new IllegalStateException("Stack is empty.");
        }
        return data[top];
    }

    public boolean isEmpty() { return top == -1; }
    public boolean isFull() { return top == data.length - 1; }
    public int size() { return top + 1; }

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
            return;
        }
        System.out.print("Stack (bottom to top): ");
        for (int i = 0; i <= top; i++) {
            System.out.print(data[i]);
            if (i < top) System.out.print(" -> ");
        }
        System.out.println(" <- TOP");
    }
}
