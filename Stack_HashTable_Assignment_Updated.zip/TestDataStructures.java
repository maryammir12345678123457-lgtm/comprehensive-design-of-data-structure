/**
 * Simple, dependency-free tests for ArrayStack and HashTable.
 * Run with: javac ArrayStack.java HashTable.java TestDataStructures.java
 *           java TestDataStructures
 */
public class TestDataStructures {
    private static int passed = 0;

    public static void main(String[] args) {
        test("stack accepts values and follows LIFO order", () -> {
            ArrayStack stack = new ArrayStack(2);
            stack.push(10);
            stack.push(20);
            check(stack.size() == 2, "stack size should be 2");
            check(stack.peek() == 20, "peek should return the top value");
            check(stack.pop() == 20, "pop should remove the most recent value");
            check(stack.pop() == 10, "next pop should return the earlier value");
            check(stack.isEmpty(), "stack should now be empty");
        });

        test("stack rejects zero and negative capacity", () -> {
            expectThrows(IllegalArgumentException.class, () -> new ArrayStack(0));
            expectThrows(IllegalArgumentException.class, () -> new ArrayStack(-1));
        });

        test("full stack rejects another push without losing values", () -> {
            ArrayStack stack = new ArrayStack(1);
            stack.push(7);
            expectThrows(IllegalStateException.class, () -> stack.push(8));
            check(stack.size() == 1 && stack.peek() == 7,
                    "failed push must not change the stack");
        });

        test("empty stack rejects pop and peek", () -> {
            ArrayStack stack = new ArrayStack(2);
            expectThrows(IllegalStateException.class, stack::pop);
            expectThrows(IllegalStateException.class, stack::peek);
            check(stack.isEmpty(), "stack should remain empty");
        });

        test("hash table adds, retrieves, and updates a key", () -> {
            HashTable table = new HashTable(5);
            table.put("apple", 10);
            check(table.get("apple") == 10, "saved value should be retrievable");
            table.put("apple", 25);
            check(table.get("apple") == 25, "same key should update its value");
            check(table.size() == 1, "updating a key must not increase size");
        });

        test("hash table handles collisions", () -> {
            // With this custom hash function, "ab" and "ba" share a bucket.
            HashTable table = new HashTable(5);
            table.put("ab", 1);
            table.put("ba", 2);
            check(table.get("ab") == 1, "first colliding key should remain accessible");
            check(table.get("ba") == 2, "second colliding key should remain accessible");
            check(table.size() == 2, "both colliding keys should be counted");
        });

        test("hash table rejects invalid capacity and null keys", () -> {
            expectThrows(IllegalArgumentException.class, () -> new HashTable(0));
            expectThrows(IllegalArgumentException.class, () -> new HashTable(-2));
            HashTable table = new HashTable(3);
            expectThrows(IllegalArgumentException.class, () -> table.put(null, 1));
            expectThrows(IllegalArgumentException.class, () -> table.get(null));
            expectThrows(IllegalArgumentException.class, () -> table.containsKey(null));
            expectThrows(IllegalArgumentException.class, () -> table.remove(null));
            check(table.isEmpty(), "invalid key must not add an entry");
        });

        test("missing key gives an error and can be checked or removed safely", () -> {
            HashTable table = new HashTable(3);
            expectThrows(IllegalArgumentException.class, () -> table.get("missing"));
            check(!table.containsKey("missing"), "missing key should not be present");
            check(!table.remove("missing"), "removing missing key should return false");
            check(table.size() == 0, "missing-key operations must not change size");
        });

        test("remove existing hash-table key", () -> {
            HashTable table = new HashTable(3);
            table.put("x", 42);
            check(table.remove("x"), "existing key should be removed");
            check(!table.containsKey("x"), "removed key should no longer exist");
            check(table.isEmpty(), "table should be empty after removal");
        });

        System.out.println();
        System.out.println("Tests passed: " + passed);
        System.out.println("All tests completed successfully.");
    }

    private static void test(String description, Runnable test) {
        try {
            test.run();
            passed++;
            System.out.println("PASS: " + description);
        } catch (Throwable error) {
            System.err.println("FAIL: " + description);
            throw error;
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void expectThrows(Class<? extends Throwable> expected, Runnable action) {
        try {
            action.run();
        } catch (Throwable actual) {
            if (expected.isInstance(actual)) return;
            throw new AssertionError("Expected " + expected.getSimpleName()
                    + " but got " + actual.getClass().getSimpleName(), actual);
        }
        throw new AssertionError("Expected " + expected.getSimpleName()
                + " but no exception was thrown");
    }
}
