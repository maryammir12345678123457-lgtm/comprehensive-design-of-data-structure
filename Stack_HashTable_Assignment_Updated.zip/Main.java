public class Main {
    // Read one line from the keyboard without importing Scanner or another input library.
    private static String readLine() {
        StringBuilder text = new StringBuilder();
        try {
            int character;
            while ((character = System.in.read()) != -1) {
                if (character == '\n') break;
                if (character != '\r') text.append((char) character);
            }
        } catch (java.io.IOException e) {
            throw new RuntimeException("Unable to read keyboard input.", e);
        }
        return text.toString().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = readLine();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = readLine();
            if (!text.isEmpty()) return text;
            System.out.println("Key cannot be empty.");
        }
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) return value;
            System.out.println("Please enter a number greater than zero.");
        }
    }

    public static void main(String[] args) {
        System.out.println("=== CUSTOM DATA STRUCTURES DEMONSTRATION ===");
        ArrayStack stack = new ArrayStack(readPositiveInt("Enter stack capacity: "));
        HashTable table = new HashTable(readPositiveInt("Enter hash table bucket count: "));

        boolean running = true;
        while (running) {
            System.out.println("\nMAIN MENU");
            System.out.println("1. Array-Based Stack");
            System.out.println("2. Hash Table");
            System.out.println("0. Exit");
            int choice = readInt("Choose: ");

            switch (choice) {
                case 1: stackMenu(stack); break;
                case 2: hashMenu(table); break;
                case 0: running = false; System.out.println("Program ended."); break;
                default: System.out.println("Please choose 0, 1, or 2.");
            }
        }
    }

    private static void stackMenu(ArrayStack stack) {
        boolean back = false;
        while (!back) {
            System.out.println("\nARRAY-BASED STACK");
            System.out.println("1. Push  2. Pop  3. Peek  4. Display");
            System.out.println("5. Size / empty / full  0. Back");
            int choice = readInt("Choose: ");
            try {
                switch (choice) {
                    case 1:
                        int value = readInt("Enter integer: ");
                        stack.push(value);
                        System.out.println("Added: " + value);
                        break;
                    case 2: System.out.println("Removed: " + stack.pop()); break;
                    case 3: System.out.println("Top value: " + stack.peek()); break;
                    case 4: stack.display(); break;
                    case 5:
                        System.out.println("Size: " + stack.size());
                        System.out.println("Empty: " + stack.isEmpty());
                        System.out.println("Full: " + stack.isFull());
                        break;
                    case 0: back = true; break;
                    default: System.out.println("Invalid option.");
                }
            } catch (IllegalStateException e) {
                System.out.println("Cannot complete operation: " + e.getMessage());
            }
        }
    }

    private static void hashMenu(HashTable table) {
        boolean back = false;
        while (!back) {
            System.out.println("\nCUSTOM HASH TABLE");
            System.out.println("1. Put / add or update  2. Get value");
            System.out.println("3. Check key  4. Remove key");
            System.out.println("5. Display buckets  6. Size / empty  0. Back");
            int choice = readInt("Choose: ");
            switch (choice) {
                case 1:
                    String key = readText("Enter key: ");
                    int value = readInt("Enter integer value: ");
                    table.put(key, value);
                    System.out.println("Saved " + key + " = " + value);
                    break;
                case 2:
                    key = readText("Enter key to search: ");
                    try { System.out.println("Value: " + table.get(key)); }
                    catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
                    break;
                case 3:
                    key = readText("Enter key to check: ");
                    System.out.println("Exists: " + table.containsKey(key));
                    break;
                case 4:
                    key = readText("Enter key to remove: ");
                    System.out.println("Removed: " + table.remove(key));
                    break;
                case 5: table.display(); break;
                case 6:
                    System.out.println("Size: " + table.size());
                    System.out.println("Empty: " + table.isEmpty());
                    break;
                case 0: back = true; break;
                default: System.out.println("Invalid option.");
            }
        }
    }
}
