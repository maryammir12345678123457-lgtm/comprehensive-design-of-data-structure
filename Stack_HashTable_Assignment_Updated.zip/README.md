# Interactive Custom Stack and Hash Table — No Scanner

- `ArrayStack.java`: custom fixed-capacity array stack using LIFO order.
- `HashTable.java`: custom bucket array, custom `Entry` nodes, custom hash function, and separate chaining for collisions.
- `Main.java`: interactive menus. Reads keyboard input using `System.in.read()` without importing `Scanner`; invalid menu numbers and non-integer input are handled, and stack/hash-table capacities must be positive.
- `TestDataStructures.java`: dependency-free tests for normal operations and invalid cases. Tests cover stack overflow/underflow, invalid capacities, hash-table updates, collisions, null keys, missing keys, and removal.

## Compile and run the program

```bash
javac ArrayStack.java HashTable.java Main.java
java Main
```

## Run the tests

```bash
javac ArrayStack.java HashTable.java TestDataStructures.java
java TestDataStructures
```

The test file uses Java assertions implemented with small helper methods, so JUnit or other external libraries are not required. A successful run prints each test as `PASS` and finishes with `All tests completed successfully.`

## Complexity

- Stack push/pop/peek/status: O(1); display O(n); space O(C).
- Hash table put/get/contains/remove: average O(1), worst O(n); size/isEmpty O(1); display O(C+n); space O(C+n).

`C` is the stack capacity or number of hash-table buckets, as applicable; `n` is the number of stored items. Java's standard classes are used for basic input, strings, integer parsing, and exceptions, but the stack and hash-table data structures are implemented manually.
